#you make a parent class apparently so you if you wanna generalize
#dog cat and bird, put it under a parent class 'Animals'

class entity:
    def __init__(self, name, hp):
        self._name = name
        self._max_hp = hp
        self._hp = hp
    
    @property
    def hp(self):
      return self._hp

    @property
    def name(self):
        return self._name
        
    def take_damage(self, dmg):
        self._hp-=dmg
        if self._hp < 0:self._hp = 0
        

    def __str__(self):
        return self._name + ': '+str(self._hp)+'/'+str(self._max_hp)