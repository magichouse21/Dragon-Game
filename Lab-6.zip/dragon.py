import entity
import random 

class dragon(entity.entity):
    def __init__(self, name, hp):
        super().__init__(name, hp)

    def basic_attack(self, hero):
        dmg = random.randint(3,7) + random.randint(3,7)
        dmg = 0
        hero.take_damage(dmg)
        return self.name+' headbutts you for '+str(dmg)+' damage!'

    def special_attack(self, hero):
        dmg = random.randint(4,8)
        hero.take_damage(dmg)
        return self.name+' sits on you for '+str(dmg)+' damage!'
      
    def __str__(self):
        return super().__str__()