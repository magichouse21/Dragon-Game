import hero
import fireDragon
import flyingDragon
import dragon
import check_input
import random


def main():
  name = input('What is your name\n')
  bob = hero.hero(name, 50)
  bobhp = bob.hp
  drag = dragon.dragon('Veryn', 10)  #initialize everything ofc
  fdrag = fireDragon.fireDragon("Lava", 15)
  fldrag = flyingDragon.flyingDragon('Tornado', 20)

  print('Welcome to dragon training, ' + name + '.')
  print('You must defeat three dragons.\n')
  arr = [drag, fdrag, fldrag]  #array all dragons
  done = False

  while not done:
    print('\n' + str(bob))

    for k in range(0, len(arr)):  #prints dragons in order
      print(str(k + 1) + '. Attack ' + str(arr[k]))

    num = check_input.get_int_range('\nChoose a dragon to attack: ', 1,
                                    len(arr))
    print('\nAttack with:\n1. Arrow (1 D12)\n2. Sword (2 D6)'
          )  #hero choosing who
    ack = check_input.get_int_range('\nEnter weapon: ', 1,
                                    2)  #and what to attack
    if ack == 1: print(bob.arrow_attack(arr[num - 1]))
    elif ack == 2: print(bob.sword_attack(arr[num - 1]))

    wdrag = random.randint(1, len(arr))  #randomnumberthatchoosesdragon
    atck = random.randint(1, 2)  #chooses dragon attack

    if atck == 1:
      print(arr[wdrag - 1].basic_attack(bob))
    elif atck == 2:
      print(arr[wdrag - 1].special_attack(bob))  #attacks hero

    for k in range(0, len(arr) - 1):
      if (arr[k].hp == 0):  #deletes dead dragon from list
        arr.pop(k)

    if (bob.hp == 0):
      done = True  #If hero dies, game ends
      print('\nGame Over! You lose! >:)')
    elif (len(arr) == 1 and arr[0].hp == 0):
      done = True  #also ends if all dragons dead (last dragon 0 hp)
      print('\nYou Win! Nice Job!')


main()
