import dragon
import random

class fireDragon(dragon.dragon):
    def __init__(self, name, hp):
        super().__init__(name, hp)
        self.f_shots = 3
    
    def special_attack(self, hero):
        if self.f_shots == 0: return self.name+' tries to spit fire at you but is all out of fire shots.'
        self.f_shots -= 1
        dmg = random.randint(5,9)
        hero.take_damage(dmg)
        return self.name+' engulfs you in flames for '+str(dmg)+' damage!'

    def __str__(self):
        return super().__str__()+'\nFire attacks remaining: '+str(self.f_shots)
