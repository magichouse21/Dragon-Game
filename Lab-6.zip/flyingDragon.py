import dragon
import random

class flyingDragon(dragon.dragon):
    def __init__(self, name, hp):
        super().__init__(name, hp)
        self.s_shots = 5
    
    def special_attack(self, hero):
        if self.s_shots == 0: return self.name+' tries to spit fire at you but is all out of fire shots.'
        self.s_shots -= 1
        dmg = random.randint(5,8)
        hero.take_damage(dmg)
        return self.name+' engulfs you in flames for '+str(dmg)+' damage!'

    def __str__(self):
        return super().__str__()+'\nSwoop attacks remaining: '+str(self.s_shots)