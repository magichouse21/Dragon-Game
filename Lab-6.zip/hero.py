import random 
import entity

class hero(entity.entity):
    def __init__(self, name, hp):
        super().__init__(name, hp)

    def sword_attack(self, dragon):
        dmg = random.randint(1,6) + random.randint(1,6)
        dragon.take_damage(dmg)
        return 'You slash the '+dragon.name+' with your sword for '+str(dmg)+' damage!'
    
    def arrow_attack(self,dragon):
        dmg = random.randint(1,12)
        dragon.take_damage(dmg)
        return 'You hit the '+dragon.name+' with an arrow for '+str(dmg)+' damage!'

    def __str__(self):
        return super().__str__()